// Change this if your backend runs on a different port/host.
const API_BASE = "http://localhost:5080";

// Must match Broker:Instruments in appsettings.json on the backend.
const SYMBOLS = ["BTC-USD", "GBPUSD", "USDJPY"];

const state = {
  prices: {}, // symbol -> { bid, ask, mid, updatedAt, prevMid }
};

// ---------- DOM refs ----------
const statusDot = document.getElementById("statusDot");
const statusText = document.getElementById("statusText");
const pricesBody = document.getElementById("pricesBody");
const orderSymbol = document.getElementById("orderSymbol");
const currentPriceLabel = document.getElementById("currentPriceLabel");
const orderQty = document.getElementById("orderQty");
const orderMessage = document.getElementById("orderMessage");
const buyBtn = document.getElementById("buyBtn");
const sellBtn = document.getElementById("sellBtn");
const tradesBody = document.getElementById("tradesBody");
const positionsBody = document.getElementById("positionsBody");

// ---------- Init symbol dropdown ----------
SYMBOLS.forEach(sym => {
  const opt = document.createElement("option");
  opt.value = sym;
  opt.textContent = sym;
  orderSymbol.appendChild(opt);
});

// ---------- Connection status UI ----------
function setStatus(status) {
  const normalized = (status || "disconnected").toLowerCase();
  statusDot.className = "status-dot " + normalized;
  const labels = {
    connecting: "Connecting",
    connected: "Connected",
    disconnected: "Disconnected",
    error: "Error",
  };
  statusText.textContent = labels[normalized] || status;
}

// ---------- Price table rendering ----------
function renderPriceRow(symbol) {
  const p = state.prices[symbol];
  if (!p) return;

  let row = document.getElementById("row-" + symbol);
  if (!row) {
    // First time we see this symbol — remove the "waiting" placeholder row.
    if (pricesBody.querySelector(".empty-row")) {
      pricesBody.innerHTML = "";
    }
    row = document.createElement("tr");
    row.id = "row-" + symbol;
    row.innerHTML = `
      <td>${symbol}</td>
      <td class="bid">-</td>
      <td class="ask">-</td>
      <td class="mid">-</td>
      <td class="updated">-</td>
    `;
    pricesBody.appendChild(row);
  }

  row.querySelector(".bid").textContent = p.bid.toFixed(5);
  row.querySelector(".ask").textContent = p.ask.toFixed(5);
  row.querySelector(".mid").textContent = p.mid.toFixed(5);
  row.querySelector(".updated").textContent = new Date(p.updatedAt).toLocaleTimeString();

  // Green/red flash on price movement (bonus feature from the assignment).
  if (p.prevMid !== undefined && p.prevMid !== p.mid) {
    row.classList.remove("flash-up", "flash-down");
    void row.offsetWidth; // restart animation
    row.classList.add(p.mid > p.prevMid ? "flash-up" : "flash-down");
  }

  // Keep the order panel's "current price" in sync with whatever symbol is selected.
  if (orderSymbol.value === symbol) {
    currentPriceLabel.textContent = p.mid.toFixed(5);
  }
}

function applyTick(tick) {
  const symbol = tick.symbol ?? tick.Symbol;
  const bid = tick.bid ?? tick.Bid;
  const ask = tick.ask ?? tick.Ask;
  const mid = tick.mid ?? tick.Mid ?? (bid + ask) / 2;
  const updatedAt = tick.updatedAt ?? tick.UpdatedAt ?? new Date().toISOString();

  const prev = state.prices[symbol];
  state.prices[symbol] = { bid, ask, mid, updatedAt, prevMid: prev ? prev.mid : undefined };
  renderPriceRow(symbol);
}

// ---------- SignalR ----------
const connection = new signalR.HubConnectionBuilder()
  .withUrl(`${API_BASE}/hubs/prices`)
  .withAutomaticReconnect([0, 2000, 5000, 10000, 10000])
  .build();

connection.on("PriceSnapshot", ticks => ticks.forEach(applyTick));
connection.on("PriceUpdate", ticks => ticks.forEach(applyTick));
connection.on("ConnectionStatus", status => setStatus(status));

connection.onreconnecting(() => setStatus("connecting"));
connection.onreconnected(() => setStatus("connected"));
connection.onclose(() => setStatus("disconnected"));

async function startConnection() {
  setStatus("connecting");
  try {
    await connection.start();
    setStatus("connected");
  } catch (err) {
    console.error("SignalR connection failed:", err);
    setStatus("error");
    setTimeout(startConnection, 5000);
  }
}
startConnection();

// Also poll /api/health once in a while as a belt-and-braces status check —
// SignalR events cover us in the normal case, this is just a safety net.
setInterval(async () => {
  try {
    const res = await fetch(`${API_BASE}/api/health`);
    const data = await res.json();
    setStatus(data.feedStatus);
  } catch {
    // Backend unreachable entirely — leave whatever SignalR last reported.
  }
}, 15000);

// ---------- Order symbol change updates the price label ----------
orderSymbol.addEventListener("change", () => {
  const p = state.prices[orderSymbol.value];
  currentPriceLabel.textContent = p ? p.mid.toFixed(5) : "--";
});

// ---------- Placing orders ----------
async function placeOrder(side) {
  const symbol = orderSymbol.value;
  const quantity = parseFloat(orderQty.value);

  if (!symbol || !quantity || quantity <= 0) {
    showOrderMessage("Enter a valid quantity.", false);
    return;
  }

  buyBtn.disabled = true;
  sellBtn.disabled = true;
  showOrderMessage("Placing order...", true);

  try {
    const res = await fetch(`${API_BASE}/api/orders`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ symbol, side, quantity }),
    });
    const result = await res.json();

    if (result.success) {
      showOrderMessage(`${side} ${quantity} ${symbol} filled at ${result.trade.price}`, true);
    } else {
      showOrderMessage(result.error || "Order rejected.", false);
    }

    await Promise.all([loadTrades(), loadPositions()]);
  } catch (err) {
    console.error(err);
    showOrderMessage("Could not reach the server.", false);
  } finally {
    buyBtn.disabled = false;
    sellBtn.disabled = false;
  }
}

function showOrderMessage(text, ok) {
  orderMessage.textContent = text;
  orderMessage.className = "order-message " + (ok ? "success" : "error");
}

buyBtn.addEventListener("click", () => placeOrder("Buy"));
sellBtn.addEventListener("click", () => placeOrder("Sell"));

// ---------- Trade history ----------
async function loadTrades() {
  try {
    const res = await fetch(`${API_BASE}/api/trades?limit=25`);
    const trades = await res.json();

    if (trades.length === 0) {
      tradesBody.innerHTML = `<tr><td colspan="7" class="empty-row">No trades yet</td></tr>`;
      return;
    }

    tradesBody.innerHTML = trades.map(t => `
      <tr>
        <td>${t.tradeId}</td>
        <td>${t.symbol}</td>
        <td>${t.side}</td>
        <td>${t.quantity}</td>
        <td>${Number(t.price).toFixed(5)}</td>
        <td>${new Date(t.timestamp).toLocaleString()}</td>
        <td>${t.status}</td>
      </tr>
    `).join("");
  } catch (err) {
    console.error("Failed to load trades:", err);
  }
}

// ---------- Positions ----------
async function loadPositions() {
  try {
    const res = await fetch(`${API_BASE}/api/positions`);
    const positions = await res.json();

    if (positions.length === 0) {
      positionsBody.innerHTML = `<tr><td colspan="5" class="empty-row">No open positions</td></tr>`;
      return;
    }

    positionsBody.innerHTML = positions.map(p => `
      <tr>
        <td>${p.symbol}</td>
        <td>${p.netQuantity}</td>
        <td>${Number(p.avgPrice).toFixed(5)}</td>
        <td>${Number(p.currentPrice).toFixed(5)}</td>
        <td style="color:${p.unrealizedPnl >= 0 ? '#22c55e' : '#ef4444'}">${Number(p.unrealizedPnl).toFixed(2)}</td>
      </tr>
    `).join("");
  } catch (err) {
    console.error("Failed to load positions:", err);
  }
}

// ---------- Initial load ----------
loadTrades();
loadPositions();
