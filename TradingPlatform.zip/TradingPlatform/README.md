# Mini Trading Platform

A real-time trading dashboard: backend authenticates with the broker's REST API, streams
live prices over WebSocket, exposes REST + SignalR endpoints to the frontend, and stores
executed trades.

## Architecture

```
Backend (ASP.NET Core 8 Web API)
├─ BrokerAuthService     → calls REST auth endpoint, caches token
├─ PriceFeedService       → background worker: connects to broker WebSocket,
│                            subscribes, parses ticks, auto-reconnects
├─ PriceStore              → thread-safe in-memory "latest price per symbol"
├─ PriceBroadcastService  → background worker: batches price changes every
│                            300ms and pushes them over SignalR (throttling)
├─ PriceHub (SignalR)     → pushes PriceUpdate / PriceSnapshot / ConnectionStatus
├─ Controllers            → /api/prices, /api/orders, /api/trades,
│                            /api/positions, /api/health
└─ SQLite (EF Core)       → trades table

Frontend (plain HTML/CSS/JS)
└─ SignalR JS client connects to /hubs/prices, renders live prices,
   order form, trade history, positions — no page reload anywhere.
```

Everything server → client for prices is push-based (SignalR), not polling.
Order placement and history/positions refresh use normal REST calls.

## Setup & Run

### 1. Backend

Requirements: .NET 8 SDK.

```bash
cd Backend/TradingPlatform.Api
dotnet restore
```

Set your demo trading account credentials as environment variables — **do not**
put them in appsettings.json:

```bash
# macOS/Linux
export Broker__Username="your_demo_username"
export Broker__Password="your_demo_password"

# Windows (PowerShell)
$env:Broker__Username="your_demo_username"
$env:Broker__Password="your_demo_password"
```

Run it:

```bash
dotnet run
```

API comes up at `http://localhost:5080` (Swagger at `/swagger` in dev mode).
The SQLite database file (`trading.db`) is created automatically on first run.

### 2. Frontend

No build step — it's plain HTML/CSS/JS. Just open `Frontend/index.html` in a
browser, or serve it with any static server, e.g.:

```bash
cd Frontend
python3 -m http.server 8080
```

Then visit `http://localhost:8080`. If your backend isn't on
`http://localhost:5080`, change `API_BASE` at the top of `Frontend/js/app.js`.

## Instruments selected

`BTC-USD`, `GBPUSD`, `USDJPY` — the three examples given in the API doc.
Configurable in `Backend/TradingPlatform.Api/appsettings.json` under
`Broker:Instruments`; if you change it there, also update the `SYMBOLS` array
at the top of `Frontend/js/app.js` to match.

## Assumptions & things to verify against the real API doc

I did not have direct access to the Postman documentation while building
this, so the following are documented assumptions rather than guesses I'm
pretending are facts:

1. **Auth request body** — `BrokerAuthService.AuthenticateAsync` currently
   sends `{ "Login": "...", "Password": "..." }`. This is a best-effort guess
   based on the standard ActTrader v2 REST auth contract. **Confirm the exact
   field names/casing against the Postman doc and adjust that one method if
   they differ** — everything downstream (token extraction, WebSocket auth)
   doesn't care what the request shape was, only that a token comes back.

2. **Auth response token field** — the token extractor scans the JSON
   response for any field named `token` (case-insensitive), up to 2 levels
   deep, rather than assuming a fixed path like `response.token`. This is
   deliberately defensive since the doc and live response can differ.

3. **Ticker message shape** — parsed as:
   ```json
   { "event": "ticker", "payload": [ { "s": "BTC-USD", "time": "...", "bid": 1.234, "ask": 1.235 } ] }
   ```
   based on the example in the doc screenshot. Fields are read defensively
   (`s` or `symbol`, string or numeric bid/ask) and anything that doesn't
   parse is logged and skipped rather than crashing the feed.

4. Order execution price uses the **mid price** `(bid + ask) / 2` at the
   moment the order is submitted, since the assignment doesn't specify a
   bid/ask-aware fill model.

## Known limitations (prototype scope)

- Position P/L uses a simple weighted-average-cost model, not FIFO/LIFO lot
  tracking — fine for a demo, not how a real broker would do it.
- Trade IDs are generated from a row count (`TRD10001`, `TRD10002`, ...) —
  under concurrent load two orders could theoretically race for the same ID.
  Not an issue for single-user demo/testing use.
- No login/auth screen for the trading platform UI itself — it's single-user,
  matching the assignment's "optional bonus" framing for that feature.
- Token refresh is time-based (10 min) rather than driven by an actual
  expiry claim, since the API doc doesn't specify token lifetime.
- CORS is wide open (`AllowAnyOrigin`-equivalent) for local dev convenience —
  would need tightening for anything beyond this assignment.

## A note on Section 3A of the assignment

The assignment asks candidates to register a demo account on a third-party
forex broker site to obtain API credentials. Worth doing with a throwaway
email/phone rather than personal details, since it's an unusual ask for a
coding assessment.
