namespace TradingPlatform.Api.Models;

// What the frontend sends when the user clicks Buy/Sell.
public class OrderRequest
{
    public string Symbol { get; set; } = string.Empty;
    public string Side { get; set; } = string.Empty; // "Buy" or "Sell"
    public decimal Quantity { get; set; }
}

// What we send back after validating + (attempting to) store the order.
public class OrderResult
{
    public bool Success { get; set; }
    public string? Error { get; set; }
    public Trade? Trade { get; set; }
}
