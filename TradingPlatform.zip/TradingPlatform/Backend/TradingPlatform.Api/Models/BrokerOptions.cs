namespace TradingPlatform.Api.Models;

// Bound from the "Broker" section of appsettings.json / environment variables.
// Username and Password are NEVER checked into source control — see README,
// they come from environment variables or dotnet user-secrets locally.
public class BrokerOptions
{
    public const string SectionName = "Broker";

    public string AuthUrl { get; set; } = "http://s138.acttrader.com:10138/api/v2/auth/token";
    public string WebSocketUrl { get; set; } = "ws://s138.acttrader.com:22138/ws";

    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;

    // Comma-separated in config, e.g. "BTC-USD,GBPUSD,USDJPY"
    public string[] Instruments { get; set; } = new[] { "BTC-USD", "GBPUSD", "USDJPY" };

    // How often we push batched price updates to the frontend over SignalR.
    public int BroadcastIntervalMs { get; set; } = 300;

    // Reconnect backoff for the WebSocket client.
    public int ReconnectDelaySeconds { get; set; } = 5;
}
