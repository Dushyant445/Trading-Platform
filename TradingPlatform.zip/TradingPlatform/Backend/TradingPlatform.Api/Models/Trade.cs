namespace TradingPlatform.Api.Models;

// This is what actually gets saved in the database once an order is filled/rejected.
public class Trade
{
    public int Id { get; set; }

    // Human-friendly id shown on the UI, e.g. TRD10018. Internally we still use the
    // int Id above as the real primary key so EF Core / SQLite don't have to deal
    // with string PKs.
    public string TradeId { get; set; } = string.Empty;

    public string Symbol { get; set; } = string.Empty;
    public string Side { get; set; } = string.Empty; // "Buy" or "Sell"
    public decimal Quantity { get; set; }
    public decimal Price { get; set; }
    public DateTime Timestamp { get; set; }
    public string Status { get; set; } = "Filled"; // Filled / Rejected
    public string? RejectReason { get; set; }
}
