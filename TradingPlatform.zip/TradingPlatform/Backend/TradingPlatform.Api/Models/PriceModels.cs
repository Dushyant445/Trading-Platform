namespace TradingPlatform.Api.Models;

// The latest known price for one symbol. This is what lives in memory
// (PriceStore) and what gets pushed to the frontend over SignalR.
public class PriceTick
{
    public string Symbol { get; set; } = string.Empty;
    public decimal Bid { get; set; }
    public decimal Ask { get; set; }
    public DateTime UpdatedAt { get; set; }

    // Mid price is what we use as "the" execution price for market orders,
    // since the assignment doesn't ask for a separate bid/ask fill model.
    public decimal Mid => Math.Round((Bid + Ask) / 2, 5);
}

// Net position per symbol, derived on the fly from stored trades.
public class Position
{
    public string Symbol { get; set; } = string.Empty;
    public decimal NetQuantity { get; set; }
    public decimal AvgPrice { get; set; }
    public decimal CurrentPrice { get; set; }
    public decimal UnrealizedPnl { get; set; }
}
