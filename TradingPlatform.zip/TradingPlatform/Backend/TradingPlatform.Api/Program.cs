using Microsoft.EntityFrameworkCore;
using TradingPlatform.Api.Data;
using TradingPlatform.Api.Hubs;
using TradingPlatform.Api.Models;
using TradingPlatform.Api.Services;

var builder = WebApplication.CreateBuilder(args);

// ---- Config ----
builder.Services.Configure<BrokerOptions>(builder.Configuration.GetSection(BrokerOptions.SectionName));

// ---- Database (SQLite, prototype-friendly, no separate server needed) ----
var dbPath = Path.Combine(AppContext.BaseDirectory, "trading.db");
builder.Services.AddDbContext<TradingDbContext>(options =>
    options.UseSqlite($"Data Source={dbPath}"));

// ---- Core services ----
builder.Services.AddHttpClient<IBrokerAuthService, BrokerAuthService>();
builder.Services.AddSingleton<PriceStore>();
builder.Services.AddSingleton<ConnectionStatusTracker>();
builder.Services.AddHostedService<PriceFeedService>();
builder.Services.AddHostedService<PriceBroadcastService>();

// ---- Web layer ----
builder.Services.AddControllers();
builder.Services.AddSignalR();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Frontend is plain static files served separately (or via file://), so we
// need CORS open for local dev. Tighten this before shipping anywhere real.
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy.AllowAnyHeader()
              .AllowAnyMethod()
              .SetIsOriginAllowed(_ => true)
              .AllowCredentials(); // needed for SignalR
    });
});

var app = builder.Build();

// ---- Ensure DB + schema exist on startup (fine for a prototype; a real
// project would use proper EF migrations instead of EnsureCreated) ----
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<TradingDbContext>();
    db.Database.EnsureCreated();
}

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowFrontend");
app.UseRouting();

app.MapControllers();
app.MapHub<PriceHub>("/hubs/prices");

app.Run();
