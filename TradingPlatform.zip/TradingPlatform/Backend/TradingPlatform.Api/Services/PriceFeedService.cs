using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using TradingPlatform.Api.Models;

namespace TradingPlatform.Api.Services;

// Runs for the lifetime of the app. Authenticates, opens the WebSocket,
// subscribes to the configured instruments, and keeps the PriceStore
// updated. Reconnects automatically (with a fixed backoff) if the socket
// drops or the initial connect fails.
public class PriceFeedService : BackgroundService
{
    private readonly IBrokerAuthService _authService;
    private readonly PriceStore _priceStore;
    private readonly ConnectionStatusTracker _statusTracker;
    private readonly BrokerOptions _options;
    private readonly ILogger<PriceFeedService> _logger;

    public PriceFeedService(
        IBrokerAuthService authService,
        PriceStore priceStore,
        ConnectionStatusTracker statusTracker,
        IOptions<BrokerOptions> options,
        ILogger<PriceFeedService> logger)
    {
        _authService = authService;
        _priceStore = priceStore;
        _statusTracker = statusTracker;
        _options = options.Value;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await RunOnce(stoppingToken);
            }
            catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
            {
                break; // normal shutdown
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Price feed loop crashed, will retry in {Delay}s", _options.ReconnectDelaySeconds);
                _statusTracker.Set(FeedStatus.Error, ex.Message);
            }

            if (!stoppingToken.IsCancellationRequested)
            {
                _statusTracker.Set(FeedStatus.Disconnected);
                await Task.Delay(TimeSpan.FromSeconds(_options.ReconnectDelaySeconds), stoppingToken);
            }
        }
    }

    private async Task RunOnce(CancellationToken ct)
    {
        _statusTracker.Set(FeedStatus.Connecting);

        string token;
        try
        {
            token = await _authService.GetTokenAsync(ct);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Could not obtain broker token — skipping this connect attempt.");
            _statusTracker.Set(FeedStatus.Error, "Authentication failed: " + ex.Message);
            return;
        }

        var wsUri = new Uri($"{_options.WebSocketUrl}?token={Uri.EscapeDataString(token)}");

        using var socket = new ClientWebSocket();
        _logger.LogInformation("Connecting to WebSocket feed...");

        try
        {
            await socket.ConnectAsync(wsUri, ct);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "WebSocket connect failed. Invalidating cached token in case it was rejected.");
            _authService.InvalidateToken();
            _statusTracker.Set(FeedStatus.Error, "WebSocket connect failed: " + ex.Message);
            return;
        }

        _statusTracker.Set(FeedStatus.Connected);
        _logger.LogInformation("WebSocket connected. Subscribing to: {Symbols}", string.Join(", ", _options.Instruments));

        await SendSubscribe(socket, _options.Instruments, ct);
        await ReceiveLoop(socket, ct);
    }

    private static async Task SendSubscribe(ClientWebSocket socket, string[] symbols, CancellationToken ct)
    {
        var message = JsonSerializer.Serialize(new { m = "subscribe", p = symbols });
        var bytes = Encoding.UTF8.GetBytes(message);
        await socket.SendAsync(bytes, WebSocketMessageType.Text, true, ct);
    }

    private async Task ReceiveLoop(ClientWebSocket socket, CancellationToken ct)
    {
        var buffer = new byte[8192];

        while (socket.State == WebSocketState.Open && !ct.IsCancellationRequested)
        {
            using var messageStream = new MemoryStream();
            WebSocketReceiveResult result;

            do
            {
                result = await socket.ReceiveAsync(buffer, ct);

                if (result.MessageType == WebSocketMessageType.Close)
                {
                    _logger.LogWarning("Broker closed the WebSocket: {Status} {Description}",
                        result.CloseStatus, result.CloseStatusDescription);
                    _statusTracker.Set(FeedStatus.Disconnected, result.CloseStatusDescription);
                    return;
                }

                messageStream.Write(buffer, 0, result.Count);
            } while (!result.EndOfMessage);

            var json = Encoding.UTF8.GetString(messageStream.ToArray());
            TryHandleMessage(json);
        }
    }

    // Parses incoming ticker messages defensively — the assignment explicitly
    // warns the live response might differ slightly from the doc, so anything
    // we can't confidently parse is logged and skipped instead of crashing
    // the feed loop.
    private void TryHandleMessage(string json)
    {
        try
        {
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            if (!root.TryGetProperty("event", out var eventProp) ||
                eventProp.GetString() != "ticker")
            {
                return; // not a price tick (could be an ack, error, orderbook msg, etc.)
            }

            if (!root.TryGetProperty("payload", out var payload) ||
                payload.ValueKind != JsonValueKind.Array)
            {
                return;
            }

            foreach (var item in payload.EnumerateArray())
            {
                ApplyTick(item);
            }
        }
        catch (JsonException ex)
        {
            _logger.LogWarning(ex, "Received malformed WebSocket message, skipping: {Raw}", Truncate(json));
        }
    }

    private void ApplyTick(JsonElement item)
    {
        string? symbol = TryGetString(item, "s") ?? TryGetString(item, "symbol");
        decimal? bid = TryGetDecimal(item, "bid");
        decimal? ask = TryGetDecimal(item, "ask");
        DateTime timestamp = TryGetDateTime(item, "time") ?? DateTime.UtcNow;

        if (symbol == null || bid == null || ask == null)
        {
            _logger.LogWarning("Ticker payload missing required fields, skipping: {Item}", item.GetRawText());
            return;
        }

        _priceStore.Update(symbol, bid.Value, ask.Value, timestamp);
    }

    private static string? TryGetString(JsonElement el, string prop) =>
        el.TryGetProperty(prop, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

    private static decimal? TryGetDecimal(JsonElement el, string prop)
    {
        if (!el.TryGetProperty(prop, out var v)) return null;
        return v.ValueKind switch
        {
            JsonValueKind.Number => v.GetDecimal(),
            JsonValueKind.String when decimal.TryParse(v.GetString(), out var d) => d,
            _ => null
        };
    }

    private static DateTime? TryGetDateTime(JsonElement el, string prop)
    {
        if (!el.TryGetProperty(prop, out var v) || v.ValueKind != JsonValueKind.String) return null;
        return DateTime.TryParse(v.GetString(), out var dt) ? dt.ToUniversalTime() : null;
    }

    private static string Truncate(string s) => s.Length > 300 ? s[..300] + "..." : s;
}
