namespace TradingPlatform.Api.Services;

public enum FeedStatus
{
    Connecting,
    Connected,
    Disconnected,
    Error
}

// Singleton so PriceFeedService (background worker) and HealthController
// (request-scoped) can share one source of truth for "is the feed up".
public class ConnectionStatusTracker
{
    public FeedStatus Status { get; private set; } = FeedStatus.Disconnected;
    public string? LastError { get; private set; }
    public DateTime LastChangedAt { get; private set; } = DateTime.UtcNow;

    public void Set(FeedStatus status, string? error = null)
    {
        Status = status;
        LastError = error;
        LastChangedAt = DateTime.UtcNow;
    }
}
