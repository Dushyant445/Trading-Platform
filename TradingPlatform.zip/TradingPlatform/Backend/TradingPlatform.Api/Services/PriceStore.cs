using System.Collections.Concurrent;
using TradingPlatform.Api.Models;

namespace TradingPlatform.Api.Services;

// Keeps the latest price per symbol in memory. Registered as a singleton so
// the WebSocket background service, the REST controllers, and the SignalR
// broadcaster all see the same data without hitting the database.
public class PriceStore
{
    private readonly ConcurrentDictionary<string, PriceTick> _prices = new();

    // Tracks which symbols have changed since the last broadcast, so the
    // throttled broadcaster only sends what actually moved instead of the
    // whole book every tick.
    private readonly ConcurrentDictionary<string, byte> _dirty = new();

    public void Update(string symbol, decimal bid, decimal ask, DateTime timestamp)
    {
        // Guard against malformed/garbage ticks — negative or zero prices,
        // or a bid above the ask, get dropped rather than corrupting the book.
        if (bid <= 0 || ask <= 0 || bid > ask)
            return;

        var tick = new PriceTick
        {
            Symbol = symbol,
            Bid = bid,
            Ask = ask,
            UpdatedAt = timestamp
        };

        _prices.AddOrUpdate(symbol, tick, (_, existing) =>
        {
            // Drop out-of-order / delayed messages: if we already have a
            // newer tick for this symbol, ignore the older one.
            return timestamp >= existing.UpdatedAt ? tick : existing;
        });

        _dirty[symbol] = 1;
    }

    public PriceTick? Get(string symbol) =>
        _prices.TryGetValue(symbol, out var tick) ? tick : null;

    public List<PriceTick> GetAll() => _prices.Values.ToList();

    // Called by the throttled broadcaster. Returns only the symbols that
    // changed since the last call, then clears the dirty flags.
    public List<PriceTick> DrainDirty()
    {
        var symbols = _dirty.Keys.ToList();
        if (symbols.Count == 0) return new List<PriceTick>();

        var result = new List<PriceTick>();
        foreach (var symbol in symbols)
        {
            _dirty.TryRemove(symbol, out _);
            if (_prices.TryGetValue(symbol, out var tick))
                result.Add(tick);
        }
        return result;
    }
}
