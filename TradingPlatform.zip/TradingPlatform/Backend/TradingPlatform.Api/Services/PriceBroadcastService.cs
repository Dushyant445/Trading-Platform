using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Options;
using TradingPlatform.Api.Hubs;
using TradingPlatform.Api.Models;

namespace TradingPlatform.Api.Services;

// This is the "don't render every tick" requirement in practice: instead of
// pushing to SignalR the instant a price changes, we batch whatever changed
// in the last BroadcastIntervalMs and send it as one message. On a fast feed
// this can turn hundreds of updates/sec into a handful of UI-friendly pushes.
public class PriceBroadcastService : BackgroundService
{
    private readonly IHubContext<PriceHub> _hub;
    private readonly PriceStore _priceStore;
    private readonly ConnectionStatusTracker _statusTracker;
    private readonly BrokerOptions _options;

    private FeedStatus? _lastBroadcastStatus;

    public PriceBroadcastService(
        IHubContext<PriceHub> hub,
        PriceStore priceStore,
        ConnectionStatusTracker statusTracker,
        IOptions<BrokerOptions> options)
    {
        _hub = hub;
        _priceStore = priceStore;
        _statusTracker = statusTracker;
        _options = options.Value;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var interval = TimeSpan.FromMilliseconds(Math.Max(_options.BroadcastIntervalMs, 50));

        while (!stoppingToken.IsCancellationRequested)
        {
            await Task.Delay(interval, stoppingToken).ContinueWith(_ => { }, TaskScheduler.Default);
            if (stoppingToken.IsCancellationRequested) break;

            var changed = _priceStore.DrainDirty();
            if (changed.Count > 0)
            {
                await _hub.Clients.All.SendAsync("PriceUpdate", changed, stoppingToken);
            }

            if (_statusTracker.Status != _lastBroadcastStatus)
            {
                _lastBroadcastStatus = _statusTracker.Status;
                await _hub.Clients.All.SendAsync("ConnectionStatus", _statusTracker.Status.ToString(), stoppingToken);
            }
        }
    }
}
