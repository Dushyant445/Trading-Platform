using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using TradingPlatform.Api.Models;

namespace TradingPlatform.Api.Services;

public interface IBrokerAuthService
{
    Task<string> GetTokenAsync(CancellationToken ct = default);
    void InvalidateToken();
}

// Handles calling the REST auth endpoint and caching the token so we don't
// re-authenticate on every request. If the WebSocket layer reports the token
// was rejected, it calls InvalidateToken() and we fetch a fresh one.
public class BrokerAuthService : IBrokerAuthService
{
    private readonly HttpClient _http;
    private readonly BrokerOptions _options;
    private readonly ILogger<BrokerAuthService> _logger;

    private string? _cachedToken;
    private DateTime _cachedAt = DateTime.MinValue;

    // We don't get an expiry from the API doc, so we conservatively
    // re-authenticate every 10 minutes even if nothing told us to.
    private static readonly TimeSpan TokenLifetime = TimeSpan.FromMinutes(10);

    private readonly SemaphoreSlim _lock = new(1, 1);

    public BrokerAuthService(HttpClient http, IOptions<BrokerOptions> options, ILogger<BrokerAuthService> logger)
    {
        _http = http;
        _options = options.Value;
        _logger = logger;
    }

    public void InvalidateToken()
    {
        _cachedToken = null;
    }

    public async Task<string> GetTokenAsync(CancellationToken ct = default)
    {
        if (_cachedToken != null && DateTime.UtcNow - _cachedAt < TokenLifetime)
            return _cachedToken;

        await _lock.WaitAsync(ct);
        try
        {
            // Another caller might have refreshed it while we were waiting.
            if (_cachedToken != null && DateTime.UtcNow - _cachedAt < TokenLifetime)
                return _cachedToken;

            _cachedToken = await AuthenticateAsync(ct);
            _cachedAt = DateTime.UtcNow;
            return _cachedToken;
        }
        finally
        {
            _lock.Release();
        }
    }

    private async Task<string> AuthenticateAsync(CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(_options.Username) || string.IsNullOrWhiteSpace(_options.Password))
        {
            throw new InvalidOperationException(
                "Broker credentials are not configured. Set Broker__Username and Broker__Password " +
                "as environment variables (see README) before starting the API.");
        }

        // NOTE: the exact request field names below (Login/Password) are my best-effort
        // guess based on the standard ActTrader v2 auth contract. Confirm the real field
        // names against the Postman doc once you have access, and adjust here if they
        // differ — this is exactly the kind of assumption the assignment asks us to document.
        var payload = new
        {
            Login = _options.Username,
            Password = _options.Password
        };

        var json = JsonSerializer.Serialize(payload);
        using var content = new StringContent(json, Encoding.UTF8, "application/json");

        _logger.LogInformation("Requesting auth token from {Url}", _options.AuthUrl);

        using var response = await _http.PostAsync(_options.AuthUrl, content, ct);
        var body = await response.Content.ReadAsStringAsync(ct);

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogError("Auth request failed: {Status} {Body}", response.StatusCode, body);
            throw new HttpRequestException($"Broker auth failed with status {response.StatusCode}: {body}");
        }

        var token = ExtractToken(body);
        if (string.IsNullOrWhiteSpace(token))
        {
            _logger.LogError("Auth response did not contain a recognizable token field: {Body}", body);
            throw new InvalidOperationException("Could not find a token in the broker auth response.");
        }

        _logger.LogInformation("Broker auth succeeded, token acquired.");
        return token;
    }

    // The API doc doesn't give us a 100% confirmed response shape, so instead of
    // hardcoding a single path like response.token, we scan the JSON for a field
    // named "token" (case-insensitive) at the top level or one level deep. This is
    // defensive against small differences between docs and live behaviour, which
    // the assignment explicitly says to expect and handle.
    private static string? ExtractToken(string body)
    {
        try
        {
            using var doc = JsonDocument.Parse(body);
            return FindToken(doc.RootElement, depth: 0);
        }
        catch (JsonException)
        {
            return null;
        }
    }

    private static string? FindToken(JsonElement element, int depth)
    {
        if (depth > 2 || element.ValueKind != JsonValueKind.Object)
            return null;

        foreach (var prop in element.EnumerateObject())
        {
            if (prop.Name.Equals("token", StringComparison.OrdinalIgnoreCase) &&
                prop.Value.ValueKind == JsonValueKind.String)
            {
                return prop.Value.GetString();
            }
        }

        foreach (var prop in element.EnumerateObject())
        {
            if (prop.Value.ValueKind == JsonValueKind.Object)
            {
                var nested = FindToken(prop.Value, depth + 1);
                if (nested != null) return nested;
            }
        }

        return null;
    }
}
