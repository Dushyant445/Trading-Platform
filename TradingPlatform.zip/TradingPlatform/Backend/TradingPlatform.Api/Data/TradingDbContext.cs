using Microsoft.EntityFrameworkCore;
using TradingPlatform.Api.Models;

namespace TradingPlatform.Api.Data;

public class TradingDbContext : DbContext
{
    public TradingDbContext(DbContextOptions<TradingDbContext> options) : base(options) { }

    public DbSet<Trade> Trades => Set<Trade>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Trade>(entity =>
        {
            entity.HasIndex(t => t.TradeId).IsUnique();
            entity.Property(t => t.Symbol).HasMaxLength(20).IsRequired();
            entity.Property(t => t.Side).HasMaxLength(10).IsRequired();
            entity.Property(t => t.Status).HasMaxLength(20).IsRequired();
        });
    }
}
