using Microsoft.AspNetCore.Mvc;
using TradingPlatform.Api.Services;

namespace TradingPlatform.Api.Controllers;

[ApiController]
[Route("api/prices")]
public class PricesController : ControllerBase
{
    private readonly PriceStore _priceStore;

    public PricesController(PriceStore priceStore)
    {
        _priceStore = priceStore;
    }

    // Mainly useful for the initial page load / fallback if SignalR hasn't
    // connected yet. Live clients get pushes instead of polling this.
    [HttpGet]
    public IActionResult GetAll()
    {
        return Ok(_priceStore.GetAll());
    }

    [HttpGet("{symbol}")]
    public IActionResult GetOne(string symbol)
    {
        var tick = _priceStore.Get(symbol);
        return tick == null ? NotFound() : Ok(tick);
    }
}
