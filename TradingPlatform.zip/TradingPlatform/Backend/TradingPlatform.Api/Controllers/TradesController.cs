using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TradingPlatform.Api.Data;

namespace TradingPlatform.Api.Controllers;

[ApiController]
[Route("api/trades")]
public class TradesController : ControllerBase
{
    private readonly TradingDbContext _db;

    public TradesController(TradingDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<IActionResult> GetTrades([FromQuery] int limit = 50)
    {
        var trades = await _db.Trades
            .OrderByDescending(t => t.Timestamp)
            .Take(Math.Clamp(limit, 1, 500))
            .ToListAsync();

        return Ok(trades);
    }
}
