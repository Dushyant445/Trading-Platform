using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TradingPlatform.Api.Data;
using TradingPlatform.Api.Models;
using TradingPlatform.Api.Services;

namespace TradingPlatform.Api.Controllers;

[ApiController]
[Route("api/positions")]
public class PositionsController : ControllerBase
{
    private readonly TradingDbContext _db;
    private readonly PriceStore _priceStore;

    public PositionsController(TradingDbContext db, PriceStore priceStore)
    {
        _db = db;
        _priceStore = priceStore;
    }

    [HttpGet]
    public async Task<IActionResult> GetPositions()
    {
        var filledTrades = await _db.Trades
            .Where(t => t.Status == "Filled")
            .ToListAsync();

        var positions = filledTrades
            .GroupBy(t => t.Symbol)
            .Select(BuildPosition)
            .Where(p => p.NetQuantity != 0)
            .ToList();

        return Ok(positions);
    }

    private Position BuildPosition(IGrouping<string, Trade> group)
    {
        // Simple weighted-average-cost model: buys add to the position at
        // their fill price, sells reduce it. Good enough for a prototype —
        // a real broker would need lot-level tracking (FIFO/LIFO), which is
        // out of scope here and noted as a known limitation in the README.
        decimal netQty = 0;
        decimal costBasis = 0;

        foreach (var trade in group.OrderBy(t => t.Timestamp))
        {
            var signedQty = trade.Side == "Buy" ? trade.Quantity : -trade.Quantity;

            if (netQty == 0 || Math.Sign(netQty) == Math.Sign(signedQty))
            {
                // Adding to the position (or opening it).
                costBasis += signedQty * trade.Price;
                netQty += signedQty;
            }
            else
            {
                // Reducing or flipping the position.
                var avgPrice = netQty != 0 ? costBasis / netQty : 0;
                netQty += signedQty;
                costBasis = avgPrice * netQty;
            }
        }

        var symbol = group.Key;
        var latest = _priceStore.Get(symbol);
        var avg = netQty != 0 ? costBasis / netQty : 0;
        var current = latest?.Mid ?? avg;

        return new Position
        {
            Symbol = symbol,
            NetQuantity = netQty,
            AvgPrice = Math.Round(avg, 5),
            CurrentPrice = current,
            UnrealizedPnl = Math.Round((current - avg) * netQty, 2)
        };
    }
}
