using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TradingPlatform.Api.Data;
using TradingPlatform.Api.Models;
using TradingPlatform.Api.Services;

namespace TradingPlatform.Api.Controllers;

[ApiController]
[Route("api/orders")]
public class OrdersController : ControllerBase
{
    private readonly TradingDbContext _db;
    private readonly PriceStore _priceStore;
    private readonly ILogger<OrdersController> _logger;

    public OrdersController(TradingDbContext db, PriceStore priceStore, ILogger<OrdersController> logger)
    {
        _db = db;
        _priceStore = priceStore;
        _logger = logger;
    }

    [HttpPost]
    public async Task<ActionResult<OrderResult>> PlaceOrder([FromBody] OrderRequest request)
    {
        var side = request.Side?.Trim();
        var symbol = request.Symbol?.Trim();

        if (string.IsNullOrWhiteSpace(symbol))
            return BadRequest(new OrderResult { Success = false, Error = "Symbol is required." });

        if (side != "Buy" && side != "Sell")
            return BadRequest(new OrderResult { Success = false, Error = "Side must be 'Buy' or 'Sell'." });

        if (request.Quantity <= 0)
            return BadRequest(new OrderResult { Success = false, Error = "Quantity must be positive." });

        var latestPrice = _priceStore.Get(symbol);
        if (latestPrice == null)
        {
            // No price yet for this symbol — save it as Rejected instead of
            // silently dropping it, so the user still sees why it failed.
            var rejected = new Trade
            {
                TradeId = await NextTradeId(),
                Symbol = symbol,
                Side = side,
                Quantity = request.Quantity,
                Price = 0,
                Timestamp = DateTime.UtcNow,
                Status = "Rejected",
                RejectReason = "No live price available for this symbol yet."
            };
            _db.Trades.Add(rejected);
            await _db.SaveChangesAsync();

            return Ok(new OrderResult { Success = false, Error = rejected.RejectReason, Trade = rejected });
        }

        var trade = new Trade
        {
            TradeId = await NextTradeId(),
            Symbol = symbol,
            Side = side,
            Quantity = request.Quantity,
            Price = latestPrice.Mid,
            Timestamp = DateTime.UtcNow,
            Status = "Filled"
        };

        _db.Trades.Add(trade);
        await _db.SaveChangesAsync();

        _logger.LogInformation("Order filled: {Side} {Qty} {Symbol} @ {Price}", side, request.Quantity, symbol, trade.Price);

        return Ok(new OrderResult { Success = true, Trade = trade });
    }

    // TRD10001, TRD10002... — simple and readable rather than a GUID, matches
    // the sample TradeId format in the assignment doc.
    private async Task<string> NextTradeId()
    {
        var count = await _db.Trades.CountAsync();
        return $"TRD{10001 + count}";
    }
}
