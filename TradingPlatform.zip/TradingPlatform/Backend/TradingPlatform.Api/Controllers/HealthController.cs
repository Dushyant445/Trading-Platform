using Microsoft.AspNetCore.Mvc;
using TradingPlatform.Api.Services;

namespace TradingPlatform.Api.Controllers;

[ApiController]
[Route("api/health")]
public class HealthController : ControllerBase
{
    private readonly ConnectionStatusTracker _statusTracker;

    public HealthController(ConnectionStatusTracker statusTracker)
    {
        _statusTracker = statusTracker;
    }

    [HttpGet]
    public IActionResult Get()
    {
        return Ok(new
        {
            api = "up",
            feedStatus = _statusTracker.Status.ToString(),
            lastError = _statusTracker.LastError,
            lastChangedAt = _statusTracker.LastChangedAt
        });
    }
}
