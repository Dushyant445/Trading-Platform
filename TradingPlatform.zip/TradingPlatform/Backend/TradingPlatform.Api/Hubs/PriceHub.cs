using Microsoft.AspNetCore.SignalR;
using TradingPlatform.Api.Services;

namespace TradingPlatform.Api.Hubs;

// Clients just connect and listen — they don't call any hub methods
// themselves for prices, everything is pushed server -> client. Having
// OnConnectedAsync send the current snapshot means a client that connects
// mid-session doesn't wait for the next tick to see prices.
public class PriceHub : Hub
{
    private readonly PriceStore _priceStore;

    public PriceHub(PriceStore priceStore)
    {
        _priceStore = priceStore;
    }

    public override async Task OnConnectedAsync()
    {
        var snapshot = _priceStore.GetAll();
        if (snapshot.Count > 0)
        {
            await Clients.Caller.SendAsync("PriceSnapshot", snapshot);
        }
        await base.OnConnectedAsync();
    }
}
